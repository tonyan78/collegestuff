# iD-Tech-Supplemental-Projects
List of projects that I created based on the iD Tech Staff Corner from my current job. 
