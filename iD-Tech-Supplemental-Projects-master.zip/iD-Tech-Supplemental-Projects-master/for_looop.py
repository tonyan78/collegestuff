
number_of_leaves = 14

for x in range(0, number_of_leaves):
    print("A leaf fell to the ground " +
    str(x) + " leaves have fallen.")

print("All the leaves fell. For loop complete.")
