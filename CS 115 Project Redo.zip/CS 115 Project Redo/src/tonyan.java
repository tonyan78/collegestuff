import java.util.*;
import java.io.*;
public class tonyan
{

	public static void main(String [] args) 
	{

		final int NUMBER_OF_EMPLOYEES = 50;
		final int NUMBER_OF_DIVISIONS = 20;
		int [] counters = new int[8];
		for(int i = 0; i < counters.length; i++)
		{
			counters[i] = 0;
		}
		String [] divisions = new String[NUMBER_OF_DIVISIONS+1];
		String line;
		int count = 0;
		tonyanEmployee [][] tae = new tonyanEmployee[NUMBER_OF_DIVISIONS+1][NUMBER_OF_EMPLOYEES+1];
		
		try 
		{
			File file = new File("emplist.txt");
			Scanner scan = new Scanner(file);
			while(scan.hasNextLine())
			{
				line = scan.nextLine();
				count++;
			}
			System.out.println("Done reading file " + count + " times");
			scan.close();
			
			scan = new Scanner(file);
			count = 0;
			divisions[count] = scan.nextLine();
			while(!divisions[count].equals("END_OF_FILE"))
			{
				int loops = scan.nextInt();
				for(int i = 0; i < loops; i++)
				{
					String ln = scan.next();
					String fn = scan.next();
					int y = scan.nextInt();
					double s = scan.nextDouble();
					String str = scan.next();
					char st = str.charAt(0);
					String j = scan.nextLine();
					tae[count][i] = new tonyanEmployee(ln, fn, y, s, st, j);
				}
				tae[count][loops] = new tonyanEmployee(); //sentinel value
				count++;
				divisions[count] = scan.nextLine();
			}
			
		}
		catch(IOException ioe)
		{
			System.out.println("Unable to read in file");
		}
		Scanner keyboard = new Scanner(System.in);
		boolean flag = true;
		while(flag)
		{
			System.out.println("Welcome. Please enter 'M' or 'm' to access the menu or 'Q' or 'q' for final stats");
			String scanin = keyboard.nextLine();
			char letter = scanin.charAt(0);
			if(letter == 'M' || letter == 'm')
			{
				menu(counters, divisions, tae);
				
			}
			else if(letter == 'Q' || letter == 'q')
			{
				flag = false;
				finalStats(counters);
			}
			else
			{
				System.out.println("You entered in the wrong character. Please try again");
				letter = scanin.charAt(0);
			}
			
			
			
		}
		
	}
	
	public static void menu(int [] counters, String [] divisions, tonyanEmployee [][] tae)
	{
		//System.out.println("Menu not implemented yet");
		Scanner scanmenu = new Scanner(System.in);
		boolean flag = true;
		int count = 0;
		while(flag)
		{
			System.out.println("Welcome to the menu");
			System.out.println("Please enter 'L' or 'l' to list all employees");
			System.out.println("Please enter 'E' or 'e' to list a specific report for an employee");
			System.out.println("Please enter 'D' or 'd' to list division report");
			System.out.println("Please enter 'S' or 's' to list salary report");
			System.out.println("Please enter 'R' or 'r' to list retirement report");
			System.out.println("Please enter 'Q' or 'q' to return back to main");
			String scanin = scanmenu.nextLine();
			char menuItems = scanin.charAt(0);
			if(menuItems == 'L' || menuItems == 'l') 
			{
				listall(divisions, tae);
				counters[0]++;
				
			}
			else if(menuItems == 'E' || menuItems == 'e')
			{
				employeeReport(divisions, tae);
				counters[1]++;
				
			}
			else if(menuItems == 'D' || menuItems == 'd')
			{
				divisionReport(divisions, tae);
				counters[2]++;
				
			}
			else if(menuItems == 'S' || menuItems == 's') 
			{
				salaryReport(divisions, tae);
				counters[3]++;
				
			}
			else if(menuItems == 'R' || menuItems == 'r')
			{
				retirementReport(divisions, tae);
				counters[4]++;
				
			}
			else if(menuItems == 'Q' || menuItems == 'q')
			{
				main(null);
				counters[5]++;
				flag = false;
			}
			else
			{
				System.out.println("You entered in the wrong character. Please try again");
				counters[6]++;
				menuItems = scanin.charAt(0);
			}
			
		}
	}
	public static void listall(String [] divisions, tonyanEmployee [][] tae)
	{
		int idx = 0;
		tonyanEmployee nemp = new tonyanEmployee();
		while(!divisions[idx].equals("END_OF_FILE"))
		{
			int empIdx = 0;
			System.out.println(divisions[idx]);
			while(!tae[idx][empIdx].equals(nemp))
			{
				System.out.println(tae[idx][empIdx].toString());
				empIdx++;
			}
			idx++;
		}
		//System.out.println("Not implemented yet");
	}
	
	public static void employeeReport(String [] divisions, tonyanEmployee [][] tae)
	{
		int idx = 0;
		boolean flag = false;
		tonyanEmployee nemp = new tonyanEmployee();
		System.out.println("Please enter in the last name of the desired employee");
		Scanner scan = new Scanner(System.in);
		String enter = scan.nextLine();
		while(!divisions[idx].equals("END_OF_FILE"))
		{
			int empIdx = 0;
			while(!tae[idx][empIdx].equals(nemp))
			{
				if(tae[idx][empIdx].getLastName().equals(enter))
				{
					System.out.println(tae[idx][empIdx].toString());
					flag = true;
				}
				empIdx++;
			}
			idx++;
		}
		if(!flag)
		{
			System.out.println("Invalid employee =(");
		}
		//System.out.println("Not implemented yet");
	}
	public static void divisionReport(String [] divisions, tonyanEmployee [][] tae)
	{
		int idx = 0;
		boolean flag = false;
		tonyanEmployee nemp = new tonyanEmployee();
		System.out.println("Please enter in the division you want information on:");
		Scanner scan = new Scanner(System.in);
		String enter = scan.nextLine();
		while(!divisions[idx].equals("END_OF_FILE"))
		{
			System.out.println(divisions[idx] + ", ");
			idx++;
		}
		System.out.println("or all:");
		idx = 0;
		String input = scan.nextLine();
		input = input.toLowerCase();
		if(input.equals("all")) 
		{
			flag = true;
			while(!divisions[idx].equals("END_OF_FILE"))
			{
				int empIdx = 0;
				System.out.println(divisions[idx]);
				while(!tae[idx][empIdx].equals(nemp))
				{
					if(tae[idx][empIdx].getLastName().equals(enter))
					{
						System.out.println(tae[idx][empIdx].toString());
						flag = true;
					}
					empIdx++;
				}
				idx++;
			}
		}
		else
		{
			while(!divisions[idx].equals("END_OF_FILE"))
			{
				if(divisions[idx].toLowerCase().equals(input))
				{
					flag = true;
					int empIdx = 0;
					while(!tae[idx][empIdx].equals(nemp))
					{
						System.out.println(tae[idx][empIdx].toString());
						empIdx++;
					}
					break;
				}
				idx++;		
			}
		}
		if(!flag)
		{
			System.out.println("Invalid division");
		}
		//System.out.println("Not implemented yet");
	}
	public static void salaryReport(String [] divisions, tonyanEmployee [][] tae)
	{
		int idx = 0;
		boolean flag = false;
		tonyanEmployee nemp = new tonyanEmployee();
		System.out.println("Please enter in the last name of the desired employee");
		Scanner scan = new Scanner(System.in);
		String enter = scan.nextLine();
		while(!divisions[idx].equals("END_OF_FILE"))
		{
			int empIdx = 0;
			while(!tae[idx][empIdx].equals(nemp))
			{
				if(tae[idx][empIdx].getLastName().equals(enter))
				{
					System.out.println(tae[idx][empIdx].getLastName() + " " 
							+ tae[idx][empIdx].getFirstName() + " " 
							+ tae[idx][empIdx].getSalary());
					flag = true;
				}
				empIdx++;
			}
			idx++;
		}
		if(!flag)
		{
			System.out.println("Invalid employee =(");
		}
		//System.out.println("Not implemented yet");
	}
	
	public static void retirementReport(String [] divisions, tonyanEmployee [][] tae)
	{
		int divIndex = 0;
		tonyanEmployee nemp = new tonyanEmployee();
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter A for active employees, R for retired, or all for all: ");
		String input = keyboard.next();
		if(input.equalsIgnoreCase("all"))
		{
			while(!divisions[divIndex].equals("END_OF_FILE"))
			{	int empIndex = 0;
				System.out.println(divisions[divIndex]);
				while(!tae[divIndex][empIndex].equals(nemp))
				{
					System.out.println(tae[divIndex][empIndex].toString());
					// Pension Calculation
					if(tae[divIndex][empIndex].getStatus() == 'r')
					{
						double pension = tae[divIndex][empIndex].getSalary();
						if (pension > (tae[divIndex][empIndex].getNumOfYears() * (pension * .02) ))
							pension = (tae[divIndex][empIndex].getNumOfYears() * (pension * .02) );
						System.out.println("Pension: " + pension);
					}
					empIndex++;
				}
				divIndex++;
			}
		}
		else if (input.equalsIgnoreCase("a")) {
			while(!divisions[divIndex].equals("END_OF_FILE"))
			{	int empIndex = 0;
				System.out.println(divisions[divIndex]);
				while(!tae[divIndex][empIndex].equals(nemp))
				{	if (tae[divIndex][empIndex].getStatus() == 'a')
						System.out.println(tae[divIndex][empIndex].toString());
					empIndex++;
				}
				divIndex++;
			}
		}
		else if (input.equalsIgnoreCase("r")) {
			while(!divisions[divIndex].equals("END_OF_FILE"))
			{	int empIndex = 0;
				System.out.println(divisions[divIndex]);
				while(!tae[divIndex][empIndex].equals(nemp))
				{	if (tae[divIndex][empIndex].getStatus() == 'r') 
					{
						System.out.println(tae[divIndex][empIndex].toString());
						// Pension Calculation
						double pension = tae[divIndex][empIndex].getSalary();
						if (pension > (tae[divIndex][empIndex].getNumOfYears() * (pension * .02) ))
							pension = (tae[divIndex][empIndex].getNumOfYears() * (pension * .02) );
						System.out.println("Pension: " + pension);
					}	
					empIndex++;
				}
				divIndex++;
			}
		}
		else {
			System.out.println("Invalid Status Entered!");
			
		}
		
		//System.out.println("Not implemented yet");
	}
	public static void finalStats(int [] counters)
	{
		System.out.println("Listall clicked " + counters[0] + " times");
		System.out.println("Employee report clicked " + counters[1] + " times");
		System.out.println("Division report clicked " + counters[2] + " times");
		System.out.println("Salary report clicked " + counters[3] + " times");
		System.out.println("Retirement report clicked " + counters[4] + " times");
		System.out.println("Main menu clicked " + counters[5] + " times");
		System.out.println("Wrong characters clicked " + counters[6] + " times");
	}
	
	
	
	
}
