
public class tonyanEmployee {


private String firstName;
private String lastName;
private int numOfYears;
private double salary;
private char status;
private String job;
private final double MINSALARY = 1000;


public tonyanEmployee()
{

	lastName = "Last Name";
	firstName = "First Name";
	numOfYears = 0;
	salary = 0.0;
	status = 'a';
	job = "Job";
	
}


public tonyanEmployee(String lastName, String firstName, int numOfYears, double salary, char status, String job)
{

	this.lastName = lastName;
	this.firstName = firstName;
	this.numOfYears = numOfYears;
	this.salary = salary;
	this.status = status;
	this.job = job;
}



public String getLastName()
{
	return lastName;
}

public String getFirstName()
{
	return firstName;
}

public int getNumOfYears()
{
	return numOfYears;
}

public double getSalary()
{
	return salary;
}

public char getStatus()
{
	return status;
}

public String getJob()
{
	return job;
}


public void setLastName(String lastName) 
{
	this.lastName = lastName;
}


public void setFirstName(String firstName)
{
	this.firstName = firstName;
}

public void setNumOfYears(int numOfYears)
{
	if(numOfYears >= 0)
		this.numOfYears = numOfYears;
	else
	{
		System.err.println("Years in company cannot be changed");
		System.err.println("Value not changed");
	}
}

public void setSalary(double salary)
{
	if(salary >= MINSALARY)
	{
	this.salary = salary;
	}
	else
	{
		System.err.println("Salary cannot be negative.");
		System.err.println("Value not changed");
	}
}

public void setStatus(char status)
{
	if(status == 'a' || status == 'r')
	{
	this.status = status;
	}
	else
	{
		System.err.println("Status must be a or r.");
		System.err.println("Value not changed");
	}
}

public void setJob(String job)
{
	this.job = job;
}

public void display() //Display methods
{

	System.out.println("Last name is" + lastName);
	System.out.println("First name is" + firstName);
	System.out.println("The amount of years in the company are" + numOfYears);
	System.out.println("The total salary is" + salary);
	System.out.println("The status is" + status);
	System.out.println("The job is" + job);
	
}
public String toString()
{
	return "Last name is " + lastName + " first name is " + firstName 
			+ " number of years is " + numOfYears + " salary is " + salary 
			+ " status is " + status + " job is " + job;
}

public boolean equals(Object o) {
	if(!(o instanceof tonyanEmployee))
		return false;
	else {
		tonyanEmployee objTonyAnEmployee = (tonyanEmployee) o;
		if(lastName.equals(objTonyAnEmployee.lastName)
				&& firstName.equals(objTonyAnEmployee.firstName)
				&& numOfYears == objTonyAnEmployee.numOfYears
				&& salary == objTonyAnEmployee.salary
				&& status == objTonyAnEmployee.status
				&& job.equals(objTonyAnEmployee.job))
				return true;
		else
			return false;
	}
}

}
 